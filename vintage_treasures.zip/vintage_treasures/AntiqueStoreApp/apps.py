from django.apps import AppConfig


class AntiquestoreappConfig(AppConfig):
    name = 'AntiqueStoreApp'
